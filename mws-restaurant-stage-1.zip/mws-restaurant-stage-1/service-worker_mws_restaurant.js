'use strict';
console.log("Running from service-worker_mws_restaurant.js");
/*var currentCache = {
  //offline: 'offline-cache' + cacheVersion
  offline: 'index'// + cacheVersion
};*/
var self = this;
self.addEventListener('install', function(e) {
 e.waitUntil(
   caches.open('restaurants').then(function(cache) {
     return cache.addAll([
	 
	 	   './',
       './index.html',
       './restaurant.html',
        './js/dbhelper.js',
       './js/main.js',

       './js/restaurant_info.js',
	   './css/styles.css',
	   './css/leaflet.css',
	   './js/leaflet.js',
	   
	   './data/restaurants.json',
	   './img/1.jpg',
	   './img/2.jpg',
	   './img/3.jpg',
	   './img/4.jpg',
	   './img/5.jpg',
	   './img/6.jpg',
	   './img/7.jpg',
	   './img/8.jpg',
	   './img/9.jpg',
	   './img/10.jpg'
	   
	   
      /*'/',
       '/index.html',
       '/restaurant.html',
        '/js/dbhelper.js',
       '/js/main.js',

       '/js/restaurant_info.js',
	   '/css/styles.css',
	   '/css/leaflet.css',
	   '/js/leaflet.js',
	   
	   '/data/restaurants.json',
	   '/img/1.jpg',
	   '/img/2.jpg',
	   '/img/3.jpg',
	   '/img/4.jpg',
	   '/img/5.jpg',
	   '/img/6.jpg',
	   '/img/7.jpg',
	   '/img/8.jpg',
	   '/img/9.jpg',
	   '/img/10.jpg'
	   */

	   /*'/mws-restaurant-stage-1',
       '/mws-restaurant-stage-1/index.html',
       '/mws-restaurant-stage-1/restaurant.html',
        '/mws-restaurant-stage-1/js/dbhelper.js',
       '/mws-restaurant-stage-1/js/main.js',
	   
	   //'/mws-restaurant-stage-1/js/leaflet.js',
       '/mws-restaurant-stage-1/js/restaurant_info.js',
	   '/mws-restaurant-stage-1/css/styles.css',
	   '/mws-restaurant-stage-1/css/leaflet.css',
	   '/mws-restaurant-stage-1/js/leaflet.js',
	   //'/mws-restaurant-stage-1/css/leaflet.css',
	   '/mws-restaurant-stage-1/data/restaurants.json',
	   '/mws-restaurant-stage-1/img/1.jpg',
	   '/mws-restaurant-stage-1/img/2.jpg',
	   '/mws-restaurant-stage-1/img/3.jpg',
	   '/mws-restaurant-stage-1/img/4.jpg',
	   '/mws-restaurant-stage-1/img/5.jpg',
	   '/mws-restaurant-stage-1/img/6.jpg',
	   '/mws-restaurant-stage-1/img/7.jpg',
	   '/mws-restaurant-stage-1/img/8.jpg',
	   '/mws-restaurant-stage-1/img/9.jpg',
	   '/mws-restaurant-stage-1/img/10.jpg',
	   //'/mws-restaurant-stage-1/css/images/marker-icon.png',
	   //'/mws-restaurant-stage-1/css/images/marker-shadow.png'
	   */
     ]);
   })
 );
});


self.addEventListener('fetch', function(event) {
 console.log(event.request.url);

 event.respondWith(
   //SAFE: caches.match(event.request).then(function(response) {
	caches.match(event.request, ignoreSearch = true).then(function(response) {
     return response || fetch(event.request);
   })
 );
});