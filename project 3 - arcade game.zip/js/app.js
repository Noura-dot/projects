// Enemy_Bug function 
var Enemy_Bug = function(x, y, speed) {
    // 
    // for started and speed
    this.x = x;
    this.y = y;
    this.speed = speed;

    //  image path  for  Enemy_Bug
    this.sprite = 'images/enemy-bug.png';
};

/////////////////
//for  Enemy_Bug speed and started position from 0 to 500
Enemy_Bug.prototype.update = function(dt) {

    this.x += this.speed * dt;

    if (this.x >= 500) {
        this.x = 0;
    }

    CheckIGirlCollisionEnemy(this);
};
/////////////////////


// show  Enemy_Bug on the screen
Enemy_Bug.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

//////////////////////////
// Girl_Player function 
var Girl_Player = function(x, y, speed) {
    this.x = x;
    this.y = y;
    this.speed = speed;
    //  image path  for  Girl_Player

    this.sprite = 'images/char-girl.png';
};
//////////////////////////
Girl_Player.prototype.update = function() {
    // function not needed right now
}

// show  Girl_Player on the screen
// show score
Girl_Player.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
    displayScoreLevel(score, gameLevel);

};
////////////

///  arrows key controll
Girl_Player.prototype.handleInput = function(keyPress) {
    if (keyPress == 'left') {
        player.x -= player.speed;
    }
    if (keyPress == 'up') {
        player.y -= player.speed - 15;
    }
    if (keyPress == 'right') {
        player.x += player.speed;
    }
    if (keyPress == 'down') {
        player.y += player.speed - 15;
    }
};
///////////
// Function to display Girl_Player score
var displayScoreLevel = function(aScore, aLevel) {
    var canvas = document.getElementsByTagName('canvas');
    var firstCanvasTag = canvas[0];

    // add score and level

 scoreLevelDiv.innerHTML = 'النقاط: ' + aScore 
        + '&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;' + 'المستوى: ' + aLevel;
    document.body.insertBefore(scoreLevelDiv, firstCanvasTag[0]);
};

var CheckIGirlCollisionEnemy = function(Enemy_Bug1) {
    //Check If Girl Collision Enemy
    if( (player.y + 150 >= Enemy_Bug1.y + 90
        && player.x - 20 <= Enemy_Bug1.x + 88
        && player.y + 73 <= Enemy_Bug1.y + 135
        && player.x + 76 >= Enemy_Bug1.x + 11) 
        || ((player.x == Enemy_Bug1.x ) && (player.y == Enemy_Bug1.y)) ){
        console.log('collided');
        player.x = 202.5;
        player.y = 383;
    }




    //Check If Girl reach to top
//level++  Score++

    if (player.y + 63 <= 0) {        
        player.x = 202.5;
        player.y = 383;

        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, 505, 171);

        score += 1;
        gameLevel += 1;

    //f increase Difficulty

        increaseDifficulty(score);

    }

    // if  girl go to   left bottom right  walls
    // to stop girl goto more stage
    if (player.y > 383 ) {
        player.y = 383;
    }
    if (player.x > 402.5) {
        player.x = 402.5;
    }
    if (player.x < 2.5) {
        player.x = 2.5;
    }
};

// Increase number  enemies every level 
var increaseDifficulty = function(numEnemies) {
    allEnemies.length = 0;


    for (var i = 0; i <= numEnemies; i++) {
        var enemy = new Enemy_Bug(0, Math.random() * 184 + 50, Math.random() * 256);
        
        allEnemies.push(enemy);
    }
};
this.boxWidth = 98;
        this.boxHeight = 67;
        this.hitbox = {x:this.x, y:this.y, width:this.boxWidth, height:this.boxHeight};

// girl started 
// Enemy_Bug randomly  vertically 
// New start Game
var allEnemies = [];
var player = new Girl_Player(200, 380, 50);
var score = 0;
var gameLevel = 1;
var scoreLevelDiv = document.createElement('div');
var enemy = new Enemy_Bug(0, Math.random() * 184 + 50, Math.random() * 256);

allEnemies.push(enemy);

// key press number code
document.addEventListener('keydown', function(e) {
    var allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down'
    };

    player.handleInput(allowedKeys[e.keyCode]);
});
