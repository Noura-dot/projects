#Classic Arcade Game Clone

##table of content
*[About](#about)
*[Author](#author)
*[Aow to play](#how to play)
*[How to install the game locally](#Howtoinstallthegamelocally)


##About

Classic Arcade Game Clone is a game where a player have to reach to the top level avoiding the insects in order to get the next level to win the game.

##Author

Noura Alkhulaif

##How to play

use swift keys in the keyboard in order to move the player so she/he can go to the top avoiding the insects which they are consedired as enemy and moving to the next level to win the game.


##How to install the game locally

by clicking on index.HTML in the zip file  that contains the entire code it will work only when the entire zip file is avaliabale in same path as index.HTML file.

