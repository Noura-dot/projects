#Feed Reader Testing 

##table of content
*[About](#about)
*[Author](#author)

*[How to open  the testing locally](#Howtoinstallthegamelocally)


##About

this project is about how to use Jasmine to write a number of tests against a pre-existing application.To test the underlying business logic of the application as well as the event handling and DOM manipulation.


##Author

Noura Alkhulaif



##How to open the testing locally

by clicking on index.HTML in the zip file  that contains the entire code it will work only when the entire zip file is avaliabale in same path as index.HTML file and then the testing applied will be shown at the end of page.